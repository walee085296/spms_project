<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight px-4">
            <?php echo e($project->title); ?>

        </h2>
        <div class="flex space-x-2">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-approve')): ?>
            <form method="GET" action="<?php echo e(route('projects.approve', $project->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['action' => 'Approve','type' => 'approve']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => 'Approve','type' => 'approve']); ?>
                     <?php $__env->slot('trigger', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'text-xs','type' => 'button','@click' => 'showModal = true','value' => 'Click Here']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-xs','type' => 'button','@click' => 'showModal = true','value' => 'Click Here']); ?>Approve
                            Project
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('title', null, []); ?> 
                        <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                            Approve Project
                        </h3>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('content', null, []); ?> 
                        <p class="text-sm text-gray-500">
                            Are you sure you want to Approve <?php echo e($project->title); ?>?
                        </p>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </form>
            <form method="GET" action="<?php echo e(route('projects.disapprove', $project->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['action' => 'Disapprove']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => 'Disapprove']); ?>
                     <?php $__env->slot('trigger', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'text-xs bg-red-700 hover:bg-red-500','type' => 'button','@click' => 'showModal = true','value' => 'Click Here']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-xs bg-red-700 hover:bg-red-500','type' => 'button','@click' => 'showModal = true','value' => 'Click Here']); ?>Disapprove Project
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('title', null, []); ?> 
                        <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                            Disapprove Project
                        </h3>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('content', null, []); ?> 
                        <p class="text-sm text-gray-500">
                            Are you sure you want to disapprove <?php echo e($project->title); ?>?
                        </p>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </form>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('complete',$project)): ?>
            <form method="GET" action="<?php echo e(route('projects.complete', $project)); ?>">
                <?php echo csrf_field(); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['action' => 'complete']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => 'complete']); ?>
                     <?php $__env->slot('trigger', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'text-xs','type' => 'button','@click' => 'showModal = true','value' => 'Click Here']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-xs','type' => 'button','@click' => 'showModal = true','value' => 'Click Here']); ?>Complete
                            Project
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('title', null, []); ?> 
                        <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                            Complete Project
                        </h3>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('content', null, []); ?> 
                        <p class="text-sm text-gray-500">
                            Are you sure you want to complete <?php echo e($project->title); ?>?
                        </p>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </form>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>
    <div class="max-w-7xl mx-auto">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>
    <div class="mx-auto max-w-7xl py-12 flex flex-col md:flex-row container items-start justify-center gap-6">
        <div class="w-full md:w-3/5">
            <div class="bg-white overflow-hidden shadow-lg rounded-3xl">
                <div class="bg-white border-b border-gray-200">
                    <div class="p-8 bg-white text-gray-800">
                        <div class="flex justify-between">
                            <h2 class="font-semibold text-xl text-gray-800 leading-tight">Project's Proposition</h2>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sync',$project)): ?>
                            <a class="text-green-600 hover:text-green-400 mr-2" href="<?php echo e(route('projects.sync',$project)); ?>"><i class="fas fa-sync-alt"></i></a>
                            <?php endif; ?>
                        </div>
                        <div class="space-y-4 p-2">
                            <div class="border-b border-gray-300 pb-4">
                                <h1 class="font-semibold text-base text-gray-800 leading-tight pb-2">Aims:</h1>
                                <ol class="list-disc list-inside">
                                    <?php $__currentLoopData = json_decode($project->aims); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex justify-between items-center text-sm py-0.5">
                                        <span class="text-sm align-middle">&#8226;<?php echo e(' '.$aim->name); ?></span>
                                        <input class="rounded-md text-gray-500" disabled type="checkbox" <?php echo e($aim->complete ? 'checked' : ''); ?>/>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </div>
                            <div class="border-b border-gray-300 pb-4">
                                <h1 class="font-semibold text-base text-gray-800 leading-tight pb-2">Objectives:</h1>
                                <ol class="list-disc list-inside">
                                    <?php $__currentLoopData = json_decode($project->objectives); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objective): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex justify-between text-center text-sm py-0.5">
                                        <span class="text-sm align-middle">&#8226;<?php echo e(' '.$objective->name); ?></span>
                                        <input class="rounded-md text-gray-500" disabled type="checkbox" <?php echo e($objective->complete ? 'checked' : ''); ?>></input>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </div>
                            <div class="">
                                <h1 class="font-semibold text-base text-gray-800 leading-tight pb-2">Tasks:</h1>
                                <ol class="list-decimal list-inside">
                                    <?php $__currentLoopData = json_decode($project->tasks); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex justify-between items-center text-sm py-1.5">
                                        <span class="text-sm align-middle"><?php echo e($key+1); ?><?php echo e('. '.$task->name); ?></span>
                                        <input class="rounded-md text-gray-500" disabled type="checkbox" <?php echo e($task->
                                        complete ? 'checked' : ''); ?>></input>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white overflow-hidden shadow-lg rounded-3xl mt-4">
                <div class="bg-white border-b border-gray-200">
                    <div class="p-8 bg-white text-gray-800">
                        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Readme.md</h2>
                        <div class="mt-2 text-sm text-gray-700">
                            <?php if(!is_array($markdown)): ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.readme','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('readme'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <?php echo $markdown ?? 'NA.'; ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                            <?php else: ?>
                            <p class="py-12">
                                No readme file yet.
                            </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="w-full md:w-1/4 space-y-4">
            <div class="bg-white overflow-hidden shadow-lg rounded-3xl">
                <div class="p-8 bg-white">
                    <div class="items-end">
                        <h2 class="font-semibold text-xl text-gray-800 leading-tight">About</h2>
                        <div class="grid grid-cols-2 gap-1 mt-2">
                            <h2 class="font-semibold text-base text-gray-800 leading-tight">Type:</h2>
                            <span class="text-sm text-gray-700 text-right capitalize"><?php echo e($project->type->value . '
                                Project'); ?></span>
                            <h2 class="font-semibold text-base text-gray-800 leading-tight">Specialization:</h2>
                            <span class="text-sm text-gray-700 text-right capitalize"><?php echo e($project->spec->value); ?></span>
                            <h2 class="font-semibold text-base text-gray-800 leading-tight">State:</h2>
                            <span class="text-sm text-gray-700 text-right capitalize"><?php echo e($project->state->value); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white overflow-hidden shadow-lg rounded-3xl">
                <div class="p-6 bg-white">
                    <div class="items-end p-2">
                        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Description</h2>
                        <p class="text-sm text-gray-700 col-span-2 pt-2"><?php echo e($github['description'] ?? 'No description
                            yet'); ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white overflow-hidden shadow-lg rounded-3xl">
                <div class="p-6 bg-white">
                    <div class="items-end p-2">
                        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Repository
                        </h2>
                        <div class="grid grid-cols-2 gap-1 mt-2">
                            <h2 class="font-semibold text-base text-gray-800 leading-tight">Github:</h2>
                            <?php if($github): ?>
                            <a href="<?php echo e($github['html_url']); ?>" target="_blank"
                                class="text-sm text-indigo-500 hover:text-indigo-700 text-right capitalize"><?php echo e($github['full_name']); ?></a>
                            <?php else: ?>
                            <span class="text-sm text-gray-700 text-right">
                                NA
                            </span>
                            <?php endif; ?>
                            <h2 class="font-semibold text-base text-gray-800 leading-tight">Open Issues:</h2>
                            <span class="text-sm text-gray-700 text-right capitalize"><?php echo e($github['open_issues_count'] ??
                                'NA'); ?></span>
                            <h2 class="font-semibold text-base text-gray-800 leading-tight col-span-2">Used Languages:
                            </h2>
                            <?php $__empty_1 = true; $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <span class="text-sm text-gray-700 text-left capitalize"><?php echo e($language); ?>:</span>
                            <span class="text-sm text-gray-700 text-right capitalize"><?php echo e(round($value/$languages->sum()*100,2).'%'); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span class="text-sm text-gray-700 text-left capitalize">
                                NA
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white overflow-hidden shadow-lg rounded-3xl">
                <div class="p-6 bg-white">
                    <div class="items-end p-2">
                        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Development Group
                        </h2>
                        <h1 class="font-semibold text-base text-gray-800 leading-tight my-2">Supervisor:</h1>
                        <?php if($project->supervisor_id): ?>
                        <a href="<?php echo e(route('users.show',$project->supervisor->id)); ?>">
                            <div class="mt-1 bg-gray-50 px-1 py-1 rounded-lg border border-gray-300 hover:bg-gray-100">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-8 w-8">
                                        <img class="h-8 w-8 rounded-full border border-gray-300"
                                            src="/uploads/avatars/<?php echo e($project->supervisor->avatar); ?>" alt="profile">
                                    </div>
                                    <div class="ml-2">
                                        <div class="text-xs font-medium text-gray-900">
                                            <?php echo e($project->supervisor->name); ?>

                                        </div>
                                        <div class="text-xs text-gray-500">
                                            <?php echo e($project->supervisor->email); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <?php if($project->supervisor_id == Auth::id()): ?>
                        <a href="<?php echo e(route('projects.abandon',$project->id)); ?>">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['action' => ''.e(__('Abandon')).'','type' => ''.e(__('button')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(__('Abandon')).'','type' => ''.e(__('button')).'']); ?>
                                 <?php $__env->slot('trigger', null, []); ?> 
                                    <button @click.prevent="showModal = true"
                                        class="mt-1 px-2 py-2 w-full bg-red-50 flex justify-center rounded-lg font-semibold text-red-700 border border-red-700 hover:border-red-500 hover:text-red-500 focus:outline-none">
                                        Abandon Project
                                    </button>
                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('title', null, []); ?> 
                                    <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                        Abandon Project
                                    </h3>
                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('content', null, []); ?> 
                                    <p class="text-sm text-gray-500">
                                        Are you sure you want abandon this project? This action
                                        will cause the project to become open for other supervisors.
                                    </p>
                                 <?php $__env->endSlot(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </a>
                        <?php endif; ?>
                        <?php else: ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-supervise')): ?>
                        <a href="<?php echo e(route('projects.supervise',$project->id)); ?>"
                            class="mt-1 py-2 bg-gray-50 px-2 flex justify-center rounded-lg font-semibold text-blue-700 border border-gray-300">Supervise
                            this project</a>
                        <?php else: ?>
                        No supervisor yet
                        <?php endif; ?>
                        <?php endif; ?>
                        <h1 class="font-semibold text-base text-gray-800 leading-tight my-2">Team:</h1>
                        <?php $__empty_1 = true; $__currentLoopData = $project->group->developers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $developer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if (! $__env->hasRenderedOnce('4ab3231a-a138-4564-a304-84785d3750a2')): $__env->markAsRenderedOnce('4ab3231a-a138-4564-a304-84785d3750a2'); ?>
                        <?php if(auth()->user()->groups->contains($project->group) || $project->supervisor == auth()->user()
                        || auth()->user()->can('project-edit')): ?>
                        <a href="<?php echo e(route('projects.unassign',$project->id)); ?>">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['action' => ''.e(__('Unassign')).'','type' => ''.e(__('button')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(__('Unassign')).'','type' => ''.e(__('button')).'']); ?>
                                 <?php $__env->slot('trigger', null, []); ?> 
                                    <button @click.prevent="showModal = true"
                                        class="px-2 py-2 w-full bg-red-50 flex justify-center rounded-lg font-semibold text-red-700 border border-red-700 hover:border-red-500 hover:text-red-500 focus:outline-none">
                                        Unassign group
                                    </button>
                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('title', null, []); ?> 
                                    <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                        Unassign group
                                    </h3>
                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('content', null, []); ?> 
                                    <p class="text-sm text-gray-500">
                                        Are you sure you want unassign your group from this project? This action
                                        will cause the project to become open for assignments.
                                    </p>
                                 <?php $__env->endSlot(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(route('requests.store',$project->group->id)); ?>"
                            class="py-2 bg-gray-50 px-2 flex justify-center rounded-lg font-semibold text-blue-700 border border-gray-300">Send
                            Join Request</a>
                        <?php endif; ?>
                        <?php endif; ?>
                        <a href="<?php echo e(route('users.show',$developer->id)); ?>">
                            <div class="mt-1 bg-gray-50 px-1 py-1 rounded-lg border border-gray-300 hover:bg-gray-100">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-8 w-8">
                                        <img class="h-8 w-8 rounded-full border border-gray-300"
                                            src="/uploads/avatars/<?php echo e($developer->avatar); ?>" alt="profile">
                                    </div>
                                    <div class="ml-2">
                                        <div class="text-xs font-medium text-gray-900">
                                            <?php echo e($developer->name); ?>

                                        </div>
                                        <div class="text-xs text-gray-500">
                                            <?php echo e($developer->email); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <a href="<?php echo e(route('projects.assign',$project->id)); ?>"
                            class="py-2 bg-gray-50 px-2 flex justify-center rounded-lg font-semibold text-blue-700 border border-gray-300">Assign
                            project</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\SPMS-main\SPMS-main\resources\views/projects/show.blade.php ENDPATH**/ ?>