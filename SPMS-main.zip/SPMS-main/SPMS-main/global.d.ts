declare module '@tailwindcss/forms';
declare module 'tailwind-scrollbar';