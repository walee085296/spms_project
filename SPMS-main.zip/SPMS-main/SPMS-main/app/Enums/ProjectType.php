<?php

namespace App\Enums;

enum ProjectType: string
{
    case Senior = 'senior';
    case Graduation1 = 'first graduation';
    case Graduation2 = 'second graduation';
}
