require('./bootstrap');
require('flowbite/dist/flowbite');
require('flowbite/dist/datepicker');
require('alpinejs');
